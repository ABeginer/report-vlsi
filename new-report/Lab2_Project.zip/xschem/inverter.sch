* inverter.sch - CMOS Inverter Schematic for Sky130 PDK
* EE121IU Lab 2 - VLSI Design Laboratory
* Created: 2026-09-26

.subckt inverter A Y VDD VSS wn=0.65 wp=1.3 l=0.15
XMP Y A VDD VDD sky130_fd_pr__pfet_01v8 L={l} W={wp} nf=1 ad={wp*0.29} as={wp*0.29} pd={2*(wp+0.29)} ps={2*(wp+0.29)} nrd={0.29/wp} nrs={0.29/wp} sa=0 sb=0 sd=0 mult=1 m=1
XMN Y A VSS VSS sky130_fd_pr__nfet_01v8 L={l} W={wn} nf=1 ad={wn*0.29} as={wn*0.29} pd={2*(wn+0.29)} ps={2*(wn+0.29)} nrd={0.29/wn} nrs={0.29/wn} sa=0 sb=0 sd=0 mult=1 m=1
.ends inverter

* Symbol: inverter.sym
* Pins: A (input), Y (output), VDD (power), VSS (ground)
