* inverter_tb.sch - Transient Testbench for CMOS Inverter
* EE121IU Lab 2 - VLSI Design Laboratory

.control
  save all
  tran 10p 100n
  write inverter_tb.raw
  plot v(in) v(out)
.endc

* Circuit connections
V0 VDD 0 DC 1.8
V1 IN 0 pulse(0 1.8 3n 3n 3n 20n 40n)
X1 IN OUT VDD 0 inverter wn=0.65 wp=1.3 l=0.15

* Net labels: IN, OUT, VDD, GND
