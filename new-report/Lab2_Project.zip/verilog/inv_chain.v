// inv_chain.v - Inverter Chain for OpenLane RTL-to-GDSII Flow
// EE121IU Lab 2 - VLSI Design Laboratory
// Sky130 PDK, 1.8V operation

module inv_chain (
    input wire clk,
    input wire en,
    output wire out
);

    // Inverter chain: 5 stages for delay measurement
    wire [4:0] inv_out;
    
    // First inverter driven by enable signal
    assign inv_out[0] = en ? ~clk : 1'b1;
    
    // Chain of inverters
    assign inv_out[1] = ~inv_out[0];
    assign inv_out[2] = ~inv_out[1];
    assign inv_out[3] = ~inv_out[2];
    assign inv_out[4] = ~inv_out[3];
    
    // Output from last stage
    assign out = inv_out[4];

endmodule
