// tb_inv_chain.v - Testbench for Inverter Chain Verification

module tb_inv_chain;

    reg clk;
    reg en;
    wire out;

    // Instantiate DUT
    inv_chain dut (
        .clk(clk),
        .en(en),
        .out(out)
    );

    initial begin
        $display("Inverter Chain Testbench Started");
        
        // Initialize signals
        clk = 0;
        en = 0;
        
        // Apply test stimulus
        #10 en = 1;
        #50 en = 0;
        #50 en = 1;
        
        $display("Testbench Finished");
        $finish;
    end

    // Clock generation: 25 MHz (40ns period)
    always #20 clk = ~clk;

endmodule
