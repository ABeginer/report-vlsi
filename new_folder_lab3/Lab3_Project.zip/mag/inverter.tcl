tech unlock *
grid 0.005um 0.005um
snap internal
box -0.20um 1.77um 2.04um 4.19um; paint nwell
box 0.25um 0.08um 1.59um 0.40um; paint psubdiff
box 0.25um 3.60um 1.59um 3.92um; paint nsubdiff
box 0.66um 0.67um 1.39um 1.32um; paint ndiff
box 0.66um 1.95um 1.39um 3.25um; paint pdiff
box 0.95um 0.54um 1.10um 3.38um; paint poly
box 0.47um 1.43um 0.95um 1.76um; paint poly
foreach y {0.80 1.05} {
    box 0.725um ${y}um 0.895um [expr {$y+0.17}]um; paint ndiffc
    box 1.155um ${y}um 1.325um [expr {$y+0.17}]um; paint ndiffc
}
foreach y {2.10 2.50 2.90} {
    box 0.725um ${y}um 0.895um [expr {$y+0.17}]um; paint pdiffc
    box 1.155um ${y}um 1.325um [expr {$y+0.17}]um; paint pdiffc
}
foreach x {0.40 0.835 1.27} {
    box ${x}um 0.155um [expr {$x+0.17}]um 0.325um; paint psubdiffcont
    box ${x}um 3.675um [expr {$x+0.17}]um 3.845um; paint nsubdiffcont
}
box 0.55um 1.51um 0.72um 1.68um; paint polycont
box 0.25um 0.075um 1.59um 0.405um; paint locali
box 0.25um 3.595um 1.59um 3.925um; paint locali
box 0.725um 0.075um 0.895um 1.34um; paint locali
box 0.725um 1.93um 0.895um 3.925um; paint locali
box 1.155um 0.65um 1.325um 3.27um; paint locali
box 0.47um 1.51um 0.80um 1.68um; paint locali
box 0um 0um 1.84um 0.48um; paint metal1
box 0um 3.52um 1.84um 4.00um; paint metal1
foreach x {0.40 0.835 1.27} {
    box ${x}um 0.155um [expr {$x+0.17}]um 0.325um; paint viali
    box ${x}um 3.675um [expr {$x+0.17}]um 3.845um; paint viali
}
box 0.55um 1.51um 0.72um 1.68um; label A c locali; port make; port class input; port use signal
box 1.155um 1.60um 1.325um 1.77um; label Y c locali; port make; port class output; port use signal
box 0.75um 3.65um 1.09um 3.87um; label VDD c metal1; port make; port class inout; port use power
box 0.75um 0.13um 1.09um 0.35um; label VSS c metal1; port make; port class inout; port use ground
box 0um 0um 1.84um 4.00um; property FIXED_BBOX [box values]
save inverter; gds write inverter.gds
drc style drc(full); drc check; drc catchup
puts "MAGIC_DRC_TOTAL=[drc count total]"
extract all; ext2spice lvs; ext2spice -o ../netgen/inverter_lay.spice
ext2spice cthresh 0; ext2spice -o ../spice/inverter_pex.spice
quit -noprompt
