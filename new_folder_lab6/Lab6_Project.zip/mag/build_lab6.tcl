tech unlock *
units microns
snap internal

# --- 1. NAND2X1 chuan template Lab 6 (1.84 x 2.72 um, 4 sites) ---
load NAND2X1
box -0.19 1.305 2.03 2.91; paint nwell
box 0.145 -0.085 0.315 0.085; paint psubdiff; paint psubdiffcont; paint locali; paint viali
box 0.145 2.635 0.315 2.805; paint nsubdiff; paint nsubdiffcont; paint locali; paint viali
box 0.560 0.235 1.540 0.885; paint ndiff
box 0.560 1.485 1.540 2.485; paint pdiff
box 0.855 0.105 1.005 2.615; paint poly
box 1.245 0.105 1.395 2.615; paint poly
box 0.595 0.995 1.005 1.325; paint poly
box 1.245 0.995 1.695 1.325; paint poly
box 0.600 0.295 0.770 0.805; paint ndiffc
box 1.430 0.335 1.600 0.805; paint ndiffc
box 0.600 1.575 0.770 2.425; paint pdiffc
box 1.040 1.575 1.210 2.425; paint pdiffc
box 1.430 1.575 1.600 2.425; paint pdiffc
box 0.640 1.075 0.810 1.245; paint polycont
box 1.480 1.075 1.650 1.245; paint polycont
box 0 -0.085 1.84 0.085; paint locali
box 0 2.635 1.84 2.805; paint locali
box 0.600 0.085 0.770 0.885; paint locali
box 0.600 1.495 0.770 2.635; paint locali
box 1.430 1.495 1.600 2.635; paint locali
box 1.040 0.855 1.210 2.465; paint locali
box 1.040 0.855 1.600 1.025; paint locali
box 1.430 0.255 1.600 1.025; paint locali
box 0.640 1.075 0.810 1.245; paint locali
box 1.480 1.075 1.650 1.245; paint locali
box 0 -0.24 1.84 0.24; paint metal1
box 0 2.48 1.84 2.96; paint metal1
box 0.640 1.075 0.810 1.245; label A c locali; port make; port class input; port use signal
box 1.480 1.075 1.650 1.245; label B c locali; port make; port class input; port use signal
box 1.040 0.855 1.210 1.025; label Y c locali; port make; port class output; port use signal
box 0 2.48 1.84 2.96; label VDD c metal1; port make; port class inout; port use power
box 0 -0.24 1.84 0.24; label VSS c metal1; port make; port class inout; port use ground
box 0 0 1.84 2.72; property FIXED_BBOX [box values]
save NAND2X1

# --- 2. INVX1 chuan Part A.2 (1.38 x 2.72 um, 3 sites, tapless) ---
load INVX1
box -0.19 1.305 1.57 2.91; paint nwell
box 0.350 0.235 1.030 0.885; paint ndiff
box 0.350 1.485 1.030 2.485; paint pdiff
box 0.615 0.105 0.765 2.615; paint poly
box 0.320 0.995 0.765 1.325; paint poly
box 0.390 0.295 0.560 0.805; paint ndiffc
box 0.820 0.335 0.990 0.805; paint ndiffc
box 0.390 1.575 0.560 2.425; paint pdiffc
box 0.820 1.575 0.990 2.385; paint pdiffc
box 0.395 1.075 0.565 1.245; paint polycont
box 0 -0.085 1.38 0.085; paint locali
box 0 2.635 1.38 2.805; paint locali
box 0.300 0.085 0.610 0.885; paint locali
box 0.300 1.495 0.580 2.635; paint locali
box 0.820 0.255 0.990 2.465; paint locali
box 0.310 1.055 0.645 1.325; paint locali
box 0 -0.24 1.38 0.24; paint metal1
box 0 2.48 1.38 2.96; paint metal1
foreach x {0.145 0.605 1.065} {
    box $x -0.085 [expr {$x+0.17}] 0.085; paint viali
    box $x 2.635 [expr {$x+0.17}] 2.805; paint viali
}
box 0.395 1.075 0.565 1.245; label A c locali; port make; port class input; port use signal
box 0.820 1.075 0.990 1.245; label Y c locali; port make; port class output; port use signal
box 0 2.48 1.38 2.96; label VDD c metal1; port make; port class inout; port use power
box 0 -0.24 1.38 0.24; label VSS c metal1; port make; port class inout; port use ground
box 0 0 1.38 2.72; property FIXED_BBOX [box values]
save INVX1
drc style drc(full); drc check; drc catchup
puts "=== INVX1 STANDALONE DRC COUNT: [drc count total] ==="

# --- 3. AND2X1 phan cap (3.22 x 2.72 um, 7 sites) theo Part D ---
load AND2X1
box 0 0 0 0; getcell NAND2X1 child 0 0
box 1.84 0 1.84 0; getcell INVX1 child 0 0
box 1.040 0.855 1.210 1.025; paint viali
box 2.235 1.075 2.405 1.245; paint viali
box 1.000 0.825 2.465 1.275; paint metal1; label net1 c metal1
box 0 -0.24 3.22 0.24; paint metal1
box 0 2.48 3.22 2.96; paint metal1
box 0.640 1.075 0.810 1.245; paint locali; label A c locali; port make; port class input; port use signal
box 1.480 1.075 1.650 1.245; paint locali; label B c locali; port make; port class input; port use signal
box 2.660 1.075 2.830 1.245; paint locali; label Y c locali; port make; port class output; port use signal
box 0 2.48 3.22 2.96; label VDD c metal1; port make; port class inout; port use power
box 0 -0.24 3.22 0.24; label VSS c metal1; port make; port class inout; port use ground
box 0 0 3.22 2.72; property FIXED_BBOX [box values]
save AND2X1
drc style drc(full); drc check; drc catchup
puts "=== AND2X1 HIERARCHICAL DRC COUNT: [drc count total] ==="

# Trich xuat LVS phan cap (Part E.1)
select top cell
extract all; ext2spice lvs; ext2spice -o ../netgen/AND2X1_lay.spice

# --- 4. Inject 2 loi LVS phan cap (Part E.3) ---
box 1.30 0.825 2.10 1.275; erase metal1
extract all; ext2spice lvs; ext2spice -o ../netgen/AND2X1_err1_open.spice
box 1.000 0.825 2.465 1.275; paint metal1
box 2.235 1.075 2.405 1.245; erase viali
box 2.405 0.825 2.465 1.275; erase metal1
box 2.665 1.075 2.835 1.245; paint viali
box 2.000 0.825 2.895 1.275; paint metal1
extract all; ext2spice lvs; ext2spice -o ../netgen/AND2X1_err2_wrongpin.spice

# --- 5. Reload AND2X1 sach va trich xuat C-only + Full RCX (Part F.1) ---
load AND2X1
flatten AND2X1_flat
load AND2X1_flat
cellname delete AND2X1
cellname rename AND2X1_flat AND2X1
select top cell
extract all; ext2spice lvs; ext2spice cthresh 0; ext2spice -o ../post_sim/AND2X1_c.spice
extract do resistance; extract all; ext2sim labels on; ext2sim
extresist minresist 0; extresist mindelay; extresist all
ext2spice lvs; ext2spice cthresh 0; ext2spice rthresh 0; ext2spice extresist on
ext2spice -o ../post_sim/AND2X1_rcx.spice
quit -noprompt
