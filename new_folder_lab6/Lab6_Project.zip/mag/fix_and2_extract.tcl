tech unlock *
units microns
snap internal

load AND2X1
flatten AND2X1_flat
load AND2X1_flat
cellname delete AND2X1
cellname rename AND2X1_flat AND2X1
select top cell
box 1.00 0.80 1.65 1.05; erase labels
box 2.60 1.00 2.90 1.30; erase labels
box 1.000 0.825 2.465 1.275; label net1 c metal1
box 2.660 1.075 2.830 1.245; label Y c locali; port make; port class output; port use signal

extract all; ext2spice lvs; ext2spice cthresh 0; ext2spice -o ../post_sim/AND2X1_c.spice
extract do resistance; extract all; ext2sim labels on; ext2sim
extresist minresist 0; extresist mindelay; extresist all
ext2spice lvs; ext2spice cthresh 0; ext2spice rthresh 0; ext2spice extresist on
ext2spice -o ../post_sim/AND2X1_rcx.spice
quit -noprompt
