create_clock [get_ports clk] -name clk -period 10.0
set_input_delay 1.0 -clock clk [get_ports {a b}]
set_output_delay 1.0 -clock clk [get_ports q]
