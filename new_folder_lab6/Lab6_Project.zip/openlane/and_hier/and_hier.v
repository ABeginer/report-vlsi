module my_nand2 (input wire a, input wire b, output wire y);
    assign y = ~(a & b);
endmodule
module my_inv (input wire a, output wire y);
    assign y = ~a;
endmodule
module my_and2 (input wire a, input wire b, output wire y);
    wire n;
    my_nand2 u_nand (.a(a), .b(b), .y(n));
    my_inv   u_inv  (.a(n), .y(y));
endmodule
module and_hier (input wire clk, input wire a, input wire b, output reg q);
    reg a_q, b_q;
    wire y_w;
    always @(posedge clk) begin a_q <= a; b_q <= b; end
    my_and2 u_and (.a(a_q), .b(b_q), .y(y_w));
    always @(posedge clk) begin q <= y_w; end
endmodule
