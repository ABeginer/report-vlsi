; Inverter Schematic - Lab 2 Design
; EE121IU · Concepts in VLSI Design Laboratory
; Sky130A PDK

.component pmos sky130_fd_sc_hd__pmos_01v8
.component nmos sky130_fd_sc_hd__nmos_01v8
.component vdd power
.component gnd ground

; PMOS: W=1.3um, L=0.15um
XPMOS A Y VDD VDD sky130_fd_sc_hd__pmos_01v8 w=1.3 l=0.15

; NMOS: W=0.65um, L=0.15um
XNMOS A Y VSS VSS sky130_fd_sc_hd__nmos_01v8 w=0.65 l=0.15

; Input and Output pins
.port A input
.port Y output
.port VDD power
.port VSS ground
