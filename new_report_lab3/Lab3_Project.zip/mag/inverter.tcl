box 0.66um 0.67um 1.39um 1.32um; paint ndiff
save inverter
drc check; drc count
gds write inverter.gds
