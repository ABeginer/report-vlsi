* Inverter Testbench - Pre-layout and Post-layout Simulation
* EE121IU · Concepts in VLSI Design Laboratory

.include "/workspace/report-vlsi/sky130A/models/sky130_fd_sc_hd.sp"

.param VDD=1.8
.param VSS=0

; Input pulse: 0V to 1.8V, 1ns rise/fall, 20ns period
Vin A 0 PULSE(0 {VDD} 0 1n 1n 10n 20n)

; Load capacitor for delay measurement
Cload Y 0 10f

; Supply connections
Vdd VDD {VDD} 0
Vss VSS {VSS} 0

; Transient analysis
.tran 0.01n 50n

; Output waveform
.plot tran V(A) V(Y)

.end
