// Inverter Testbench - Verilog
// EE121IU · Concepts in VLSI Design Laboratory

module inverter_tb;
    reg A;
    wire Y, VDD, VSS;
    
    // Instantiate the inverter
    inverter uut (
        .A(A),
        .Y(Y),
        .VDD(VDD),
        .VSS(VSS)
    );
    
    initial begin
        VDD = 1.8;
        VSS = 0;
        
        // Test sequence
        #0 A = 0;
        #5 A = 1;
        #10 A = 0;
        #15 A = 1;
        #20 $finish;
    end
    
    initial begin
        $dumpfile("waveform.vcd");
        $dumpvars(0, inverter_tb);
    end
endmodule
