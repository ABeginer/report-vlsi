tech unlock *
grid 0.005um 0.005um
snap internal
# 1. N-well & taps (nsubdiff y=2.96..3.14, psubdiff y=0.06..0.24)
box -0.20um 1.65um 1.92um 3.50um; paint nwell
box 0.14um 0.06um 1.58um 0.24um; paint psubdiff
box 0.14um 2.96um 1.58um 3.14um; paint nsubdiff
# 2. Active regions: NMOS y=0.55..1.20 (W=0.65), PMOS y=1.85..2.65 (W=0.80)
box 0.25um 0.55um 1.47um 1.20um; paint ndiff
box 0.25um 1.85um 1.47um 2.65um; paint pdiff
# 3. Dual polysilicon gates (L=0.15, y=0.42..2.78 -> poly endcap 0.13um, clear of taps!)
box 0.62um 0.42um 0.77um 2.78um; paint poly
box 1.01um 0.42um 1.16um 2.78um; paint poly
box 0.25um 1.32um 0.77um 1.52um; paint poly
box 1.01um 1.32um 1.47um 1.52um; paint poly
# 4. Contacts (licon1)
foreach y {0.65 0.93} {
    box 0.33um ${y}um 0.50um [expr {$y+0.17}]um; paint ndiffc
    box 1.22um ${y}um 1.39um [expr {$y+0.17}]um; paint ndiffc
}
foreach y {1.96 2.36} {
    box 0.33um ${y}um 0.50um [expr {$y+0.17}]um; paint pdiffc
    box 0.805um ${y}um 0.975um [expr {$y+0.17}]um; paint pdiffc
    box 1.22um ${y}um 1.39um [expr {$y+0.17}]um; paint pdiffc
}
foreach x {0.33 0.805 1.22} {
    box ${x}um 0.065um [expr {$x+0.17}]um 0.235um; paint psubdiffcont
    box ${x}um 2.965um [expr {$x+0.17}]um 3.135um; paint nsubdiffcont
}
box 0.28um 1.335um 0.45um 1.505um; paint polycont
box 1.27um 1.335um 1.44um 1.505um; paint polycont
# 5. Local interconnect (li1) + Metal1 bridge for Y (keeps Y completely separated from B!)
box 0.14um 0.06um 1.58um 0.24um; paint locali
box 0.14um 2.96um 1.58um 3.14um; paint locali
box 0.33um 0.065um 0.50um 1.10um; paint locali
box 0.33um 1.96um 0.50um 3.135um; paint locali
box 1.22um 1.96um 1.39um 3.135um; paint locali
box 0.805um 1.96um 0.975um 2.53um; paint locali
box 1.22um 0.65um 1.39um 1.10um; paint locali
box 0.28um 1.335um 0.45um 1.505um; paint locali
box 1.27um 1.335um 1.44um 1.505um; paint locali
# 6. Metal1 power rails + Metal1 output Y bridge + pins
box 0um 0um 1.72um 0.48um; paint metal1
box 0um 2.72um 1.72um 3.20um; paint metal1
foreach x {0.33 0.805 1.22} {
    box ${x}um 0.065um [expr {$x+0.17}]um 0.235um; paint viali
    box ${x}um 2.965um [expr {$x+0.17}]um 3.135um; paint viali
}
box 0.805um 1.96um 0.975um 2.13um; paint viali
box 1.22um 0.93um 1.39um 1.10um; paint viali
box 0.805um 0.93um 1.39um 1.10um; paint metal1
box 0.805um 0.93um 0.975um 2.13um; paint metal1
box 0.28um 1.335um 0.45um 1.505um; label A c locali; port make; port class input; port use signal
box 1.27um 1.335um 1.44um 1.505um; label B c locali; port make; port class input; port use signal
box 0.805um 1.50um 0.975um 1.70um; label Y c metal1; port make; port class output; port use signal
box 0.72um 2.86um 1.00um 3.06um; label VPWR c metal1; port make; port class inout; port use power
box 0.72um 0.14um 1.00um 0.34um; label VGND c metal1; port make; port class inout; port use ground
box 0um 0um 1.72um 3.20um; property FIXED_BBOX [box values]
save NAND2X1; gds write NAND2X1.gds; lef write ../lef/NAND2X1.lef -pinonly
drc style drc(full); drc check; drc catchup
puts "LAB5_DRC_COUNT=[drc count total]"
extract all; ext2spice lvs; ext2spice -o ../netgen/NAND2X1_lay.spice
ext2spice cthresh 0; ext2spice -o ../spice/NAND2X1_c.spice
extract do resistance; extract all; ext2sim labels on; ext2sim; extresist all
ext2spice lvs; ext2spice cthresh 0; ext2spice rthresh 0; ext2spice extresist on
ext2spice -o ../spice/NAND2X1_rcx.spice
quit -noprompt
