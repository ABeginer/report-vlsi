load NAND2X1
property LEFclass CORE
property LEFsite unithd
property LEFsymmetry "X Y"
lef write -hide
gds write NAND2X1.gds
save NAND2X1
quit -noprompt
