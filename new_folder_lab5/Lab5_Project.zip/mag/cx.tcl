load NAND2X1
flatten NAND2X1_c
load NAND2X1_c
cellname delete NAND2X1
cellname rename NAND2X1_c NAND2X1
select top cell
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice -o ../post_sim/NAND2X1_c.spice
quit -noprompt
