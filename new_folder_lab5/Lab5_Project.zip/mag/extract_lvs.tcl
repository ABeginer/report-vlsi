load NAND2X1
select top cell
extract all
ext2spice lvs
ext2spice -o ../netgen/NAND2X1_lay.spice
quit -noprompt
