v {xschem version=3.4.5 file_version=1.2}
G {NAND2X1 schematic Wp=1.0 Wn=0.65 L=0.15}
