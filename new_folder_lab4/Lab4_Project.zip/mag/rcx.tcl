load inverter
select top cell
extract do resistance
extract all
ext2sim labels on
ext2sim
extresist minresist 0
extresist mindelay 0
extresist all
ext2spice lvs
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o ../post_sim/inverter_rcx.spice
quit -noprompt
