load inverter
select top cell
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice -o ../post_sim/inverter_c.spice
extract no coupling
extract all
ext2spice -o ../post_sim/inverter_c_decoupled.spice
quit -noprompt
